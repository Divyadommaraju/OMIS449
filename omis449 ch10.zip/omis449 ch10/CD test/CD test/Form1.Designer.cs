﻿namespace CD_test
{
    partial class CDAForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EnterGroupBox = new System.Windows.Forms.GroupBox();
            this.accountNumberTextbox = new System.Windows.Forms.TextBox();
            this.accountNumberLabel = new System.Windows.Forms.Label();
            this.interestRateLabel = new System.Windows.Forms.Label();
            this.BalLabel = new System.Windows.Forms.Label();
            this.MaturityLabel = new System.Windows.Forms.Label();
            this.InterestTextbox = new System.Windows.Forms.TextBox();
            this.BalanceTextbox = new System.Windows.Forms.TextBox();
            this.MaturityDateTextbox = new System.Windows.Forms.TextBox();
            this.ObjectGroupBox = new System.Windows.Forms.GroupBox();
            this.AccountLabel = new System.Windows.Forms.Label();
            this.IntLabel = new System.Windows.Forms.Label();
            this.balanceLabel = new System.Windows.Forms.Label();
            this.MaturityDateLabel = new System.Windows.Forms.Label();
            this.AccNTextBox = new System.Windows.Forms.TextBox();
            this.InterestRateTextBox = new System.Windows.Forms.TextBox();
            this.balTextBox = new System.Windows.Forms.TextBox();
            this.MatTextbox = new System.Windows.Forms.TextBox();
            this.CreateButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.EnterGroupBox.SuspendLayout();
            this.ObjectGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // EnterGroupBox
            // 
            this.EnterGroupBox.Controls.Add(this.MaturityDateTextbox);
            this.EnterGroupBox.Controls.Add(this.BalanceTextbox);
            this.EnterGroupBox.Controls.Add(this.InterestTextbox);
            this.EnterGroupBox.Controls.Add(this.MaturityLabel);
            this.EnterGroupBox.Controls.Add(this.BalLabel);
            this.EnterGroupBox.Controls.Add(this.interestRateLabel);
            this.EnterGroupBox.Controls.Add(this.accountNumberLabel);
            this.EnterGroupBox.Controls.Add(this.accountNumberTextbox);
            this.EnterGroupBox.Location = new System.Drawing.Point(32, 33);
            this.EnterGroupBox.Name = "EnterGroupBox";
            this.EnterGroupBox.Size = new System.Drawing.Size(302, 333);
            this.EnterGroupBox.TabIndex = 0;
            this.EnterGroupBox.TabStop = false;
            this.EnterGroupBox.Text = "Enter CD Account Data";
            // 
            // accountNumberTextbox
            // 
            this.accountNumberTextbox.Location = new System.Drawing.Point(183, 59);
            this.accountNumberTextbox.Name = "accountNumberTextbox";
            this.accountNumberTextbox.Size = new System.Drawing.Size(100, 26);
            this.accountNumberTextbox.TabIndex = 0;
            // 
            // accountNumberLabel
            // 
            this.accountNumberLabel.AutoSize = true;
            this.accountNumberLabel.Location = new System.Drawing.Point(6, 59);
            this.accountNumberLabel.Name = "accountNumberLabel";
            this.accountNumberLabel.Size = new System.Drawing.Size(128, 20);
            this.accountNumberLabel.TabIndex = 1;
            this.accountNumberLabel.Text = "Account Number";
            // 
            // interestRateLabel
            // 
            this.interestRateLabel.AutoSize = true;
            this.interestRateLabel.Location = new System.Drawing.Point(10, 126);
            this.interestRateLabel.Name = "interestRateLabel";
            this.interestRateLabel.Size = new System.Drawing.Size(103, 20);
            this.interestRateLabel.TabIndex = 2;
            this.interestRateLabel.Text = "Interest Rate";
            // 
            // BalLabel
            // 
            this.BalLabel.AutoSize = true;
            this.BalLabel.Location = new System.Drawing.Point(10, 188);
            this.BalLabel.Name = "BalLabel";
            this.BalLabel.Size = new System.Drawing.Size(67, 20);
            this.BalLabel.TabIndex = 3;
            this.BalLabel.Text = "Balance";
            // 
            // MaturityLabel
            // 
            this.MaturityLabel.AutoSize = true;
            this.MaturityLabel.Location = new System.Drawing.Point(14, 266);
            this.MaturityLabel.Name = "MaturityLabel";
            this.MaturityLabel.Size = new System.Drawing.Size(104, 20);
            this.MaturityLabel.TabIndex = 4;
            this.MaturityLabel.Text = "Maturity Date";
            // 
            // InterestTextbox
            // 
            this.InterestTextbox.Location = new System.Drawing.Point(183, 120);
            this.InterestTextbox.Name = "InterestTextbox";
            this.InterestTextbox.Size = new System.Drawing.Size(100, 26);
            this.InterestTextbox.TabIndex = 5;
            // 
            // BalanceTextbox
            // 
            this.BalanceTextbox.Location = new System.Drawing.Point(183, 181);
            this.BalanceTextbox.Name = "BalanceTextbox";
            this.BalanceTextbox.Size = new System.Drawing.Size(100, 26);
            this.BalanceTextbox.TabIndex = 6;
            // 
            // MaturityDateTextbox
            // 
            this.MaturityDateTextbox.Location = new System.Drawing.Point(183, 259);
            this.MaturityDateTextbox.Name = "MaturityDateTextbox";
            this.MaturityDateTextbox.Size = new System.Drawing.Size(100, 26);
            this.MaturityDateTextbox.TabIndex = 7;
            // 
            // ObjectGroupBox
            // 
            this.ObjectGroupBox.Controls.Add(this.MatTextbox);
            this.ObjectGroupBox.Controls.Add(this.balTextBox);
            this.ObjectGroupBox.Controls.Add(this.InterestRateTextBox);
            this.ObjectGroupBox.Controls.Add(this.AccNTextBox);
            this.ObjectGroupBox.Controls.Add(this.MaturityDateLabel);
            this.ObjectGroupBox.Controls.Add(this.balanceLabel);
            this.ObjectGroupBox.Controls.Add(this.IntLabel);
            this.ObjectGroupBox.Controls.Add(this.AccountLabel);
            this.ObjectGroupBox.Location = new System.Drawing.Point(456, 44);
            this.ObjectGroupBox.Name = "ObjectGroupBox";
            this.ObjectGroupBox.Size = new System.Drawing.Size(318, 322);
            this.ObjectGroupBox.TabIndex = 1;
            this.ObjectGroupBox.TabStop = false;
            this.ObjectGroupBox.Text = "ObjectProperties";
            // 
            // AccountLabel
            // 
            this.AccountLabel.AutoSize = true;
            this.AccountLabel.Location = new System.Drawing.Point(16, 47);
            this.AccountLabel.Name = "AccountLabel";
            this.AccountLabel.Size = new System.Drawing.Size(124, 20);
            this.AccountLabel.TabIndex = 0;
            this.AccountLabel.Text = "AccountNumber";
            // 
            // IntLabel
            // 
            this.IntLabel.AutoSize = true;
            this.IntLabel.Location = new System.Drawing.Point(20, 114);
            this.IntLabel.Name = "IntLabel";
            this.IntLabel.Size = new System.Drawing.Size(103, 20);
            this.IntLabel.TabIndex = 1;
            this.IntLabel.Text = "Interest Rate";
            // 
            // balanceLabel
            // 
            this.balanceLabel.AutoSize = true;
            this.balanceLabel.Location = new System.Drawing.Point(20, 176);
            this.balanceLabel.Name = "balanceLabel";
            this.balanceLabel.Size = new System.Drawing.Size(67, 20);
            this.balanceLabel.TabIndex = 2;
            this.balanceLabel.Text = "Balance";
            // 
            // MaturityDateLabel
            // 
            this.MaturityDateLabel.AutoSize = true;
            this.MaturityDateLabel.Location = new System.Drawing.Point(24, 254);
            this.MaturityDateLabel.Name = "MaturityDateLabel";
            this.MaturityDateLabel.Size = new System.Drawing.Size(104, 20);
            this.MaturityDateLabel.TabIndex = 3;
            this.MaturityDateLabel.Text = "Maturity Date";
            // 
            // AccNTextBox
            // 
            this.AccNTextBox.Location = new System.Drawing.Point(200, 41);
            this.AccNTextBox.Name = "AccNTextBox";
            this.AccNTextBox.Size = new System.Drawing.Size(100, 26);
            this.AccNTextBox.TabIndex = 4;
            // 
            // InterestRateTextBox
            // 
            this.InterestRateTextBox.Location = new System.Drawing.Point(200, 108);
            this.InterestRateTextBox.Name = "InterestRateTextBox";
            this.InterestRateTextBox.Size = new System.Drawing.Size(100, 26);
            this.InterestRateTextBox.TabIndex = 5;
            // 
            // balTextBox
            // 
            this.balTextBox.Location = new System.Drawing.Point(200, 177);
            this.balTextBox.Name = "balTextBox";
            this.balTextBox.Size = new System.Drawing.Size(100, 26);
            this.balTextBox.TabIndex = 6;
            // 
            // MatTextbox
            // 
            this.MatTextbox.Location = new System.Drawing.Point(200, 248);
            this.MatTextbox.Name = "MatTextbox";
            this.MatTextbox.Size = new System.Drawing.Size(100, 26);
            this.MatTextbox.TabIndex = 7;
            // 
            // CreateButton
            // 
            this.CreateButton.Location = new System.Drawing.Point(200, 463);
            this.CreateButton.Name = "CreateButton";
            this.CreateButton.Size = new System.Drawing.Size(150, 44);
            this.CreateButton.TabIndex = 2;
            this.CreateButton.Text = "Create Object";
            this.CreateButton.UseVisualStyleBackColor = true;
            this.CreateButton.Click += new System.EventHandler(this.createObjectButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(558, 463);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(101, 44);
            this.ExitButton.TabIndex = 3;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // CDAForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(877, 544);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.CreateButton);
            this.Controls.Add(this.ObjectGroupBox);
            this.Controls.Add(this.EnterGroupBox);
            this.Name = "CDAForm";
            this.Text = "CD Account Test";
            this.EnterGroupBox.ResumeLayout(false);
            this.EnterGroupBox.PerformLayout();
            this.ObjectGroupBox.ResumeLayout(false);
            this.ObjectGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox EnterGroupBox;
        private System.Windows.Forms.TextBox MaturityDateTextbox;
        private System.Windows.Forms.TextBox BalanceTextbox;
        private System.Windows.Forms.TextBox InterestTextbox;
        private System.Windows.Forms.Label MaturityLabel;
        private System.Windows.Forms.Label BalLabel;
        private System.Windows.Forms.Label interestRateLabel;
        private System.Windows.Forms.Label accountNumberLabel;
        private System.Windows.Forms.TextBox accountNumberTextbox;
        private System.Windows.Forms.GroupBox ObjectGroupBox;
        private System.Windows.Forms.TextBox MatTextbox;
        private System.Windows.Forms.TextBox balTextBox;
        private System.Windows.Forms.TextBox InterestRateTextBox;
        private System.Windows.Forms.TextBox AccNTextBox;
        private System.Windows.Forms.Label MaturityDateLabel;
        private System.Windows.Forms.Label balanceLabel;
        private System.Windows.Forms.Label IntLabel;
        private System.Windows.Forms.Label AccountLabel;
        private System.Windows.Forms.Button CreateButton;
        private System.Windows.Forms.Button ExitButton;
    }
}

