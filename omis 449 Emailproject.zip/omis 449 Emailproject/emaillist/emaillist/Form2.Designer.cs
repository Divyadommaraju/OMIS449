﻿namespace emaillist
{
    partial class Details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.displayPhoneLabel = new System.Windows.Forms.Label();
            this.displaylnLabel = new System.Windows.Forms.Label();
            this.displayfnLabel = new System.Windows.Forms.Label();
            this.phoneLabel = new System.Windows.Forms.Label();
            this.LNLabel = new System.Windows.Forms.Label();
            this.fnLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // displayPhoneLabel
            // 
            this.displayPhoneLabel.AutoSize = true;
            this.displayPhoneLabel.Location = new System.Drawing.Point(617, 224);
            this.displayPhoneLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.displayPhoneLabel.Name = "displayPhoneLabel";
            this.displayPhoneLabel.Size = new System.Drawing.Size(63, 20);
            this.displayPhoneLabel.TabIndex = 11;
            this.displayPhoneLabel.Text = "Label 6";
            // 
            // displaylnLabel
            // 
            this.displaylnLabel.AutoSize = true;
            this.displaylnLabel.Location = new System.Drawing.Point(348, 224);
            this.displaylnLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.displaylnLabel.Name = "displaylnLabel";
            this.displaylnLabel.Size = new System.Drawing.Size(63, 20);
            this.displaylnLabel.TabIndex = 10;
            this.displaylnLabel.Text = "Label 2";
            // 
            // displayfnLabel
            // 
            this.displayfnLabel.AutoSize = true;
            this.displayfnLabel.Location = new System.Drawing.Point(58, 224);
            this.displayfnLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.displayfnLabel.Name = "displayfnLabel";
            this.displayfnLabel.Size = new System.Drawing.Size(63, 20);
            this.displayfnLabel.TabIndex = 9;
            this.displayfnLabel.Text = "Label 1";
            // 
            // phoneLabel
            // 
            this.phoneLabel.AutoSize = true;
            this.phoneLabel.Location = new System.Drawing.Point(617, 72);
            this.phoneLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.phoneLabel.Name = "phoneLabel";
            this.phoneLabel.Size = new System.Drawing.Size(114, 20);
            this.phoneLabel.TabIndex = 8;
            this.phoneLabel.Text = "PhoneNumber";
            // 
            // LNLabel
            // 
            this.LNLabel.AutoSize = true;
            this.LNLabel.Location = new System.Drawing.Point(348, 72);
            this.LNLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LNLabel.Name = "LNLabel";
            this.LNLabel.Size = new System.Drawing.Size(83, 20);
            this.LNLabel.TabIndex = 7;
            this.LNLabel.Text = "LastName";
            // 
            // fnLabel
            // 
            this.fnLabel.AutoSize = true;
            this.fnLabel.Location = new System.Drawing.Point(58, 72);
            this.fnLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.fnLabel.Name = "fnLabel";
            this.fnLabel.Size = new System.Drawing.Size(84, 20);
            this.fnLabel.TabIndex = 6;
            this.fnLabel.Text = "FirstName";
            // 
            // Details
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(889, 450);
            this.Controls.Add(this.displayPhoneLabel);
            this.Controls.Add(this.displaylnLabel);
            this.Controls.Add(this.displayfnLabel);
            this.Controls.Add(this.phoneLabel);
            this.Controls.Add(this.LNLabel);
            this.Controls.Add(this.fnLabel);
            this.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Details";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Details_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label displayPhoneLabel;
        public System.Windows.Forms.Label displaylnLabel;
        public System.Windows.Forms.Label displayfnLabel;
        private System.Windows.Forms.Label phoneLabel;
        private System.Windows.Forms.Label LNLabel;
        private System.Windows.Forms.Label fnLabel;
    }
}