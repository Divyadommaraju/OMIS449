﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace emaillist
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


             List<PersonsEntry> Entries = new List<PersonsEntry>();

        private void Form1_Load(object sender, EventArgs e)
        {
            StreamReader File = new StreamReader("EmailList.txt");

        
            string s;
            string name = "";
            string email = "";
            string phone = "";
            int i;

            while ((s = File.ReadLine()) != null)
            {
                i = 0;
               
                char delim = ',';

                string[] Lines = s.Split(delim);

                foreach (var substring in Lines)
                {
                    if (i == 0)
                    {
                        name = substring;
                    }

                    else if (i == 1)
                    {
                        email = substring;
                    }

                    else
                    {
                        phone = substring;
                    }

                    i = i + 1;
                }

        
                PersonsEntry Person = new PersonsEntry(name, email, phone);
                Entries.Add(Person);

                People.Items.Add(name);
            }
        }

    
        private void People_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = People.SelectedIndex;

            Details AdditionalInfo = new Details();

            AdditionalInfo.displayfnLabel.Text = Entries[index].Name.ToString();
            AdditionalInfo.displaylnLabel.Text = Entries[index].Email.ToString();
            AdditionalInfo.displayPhoneLabel.Text = Entries[index].Phone.ToString();

            AdditionalInfo.Show();
        }
    }
}