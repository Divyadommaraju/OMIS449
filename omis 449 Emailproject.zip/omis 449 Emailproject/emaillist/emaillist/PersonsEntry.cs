﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace emaillist
{
    class PersonsEntry
    {
    
        public string Name;
        public string Email;
        public string Phone;

        public PersonsEntry(string name, string email, string phone)
        {
            Name = name;
            Email = email;
            Phone = phone;
        }
    }
}

 