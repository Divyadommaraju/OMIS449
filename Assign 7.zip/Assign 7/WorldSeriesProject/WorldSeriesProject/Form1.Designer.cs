﻿namespace WorldSeriesProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitButton = new System.Windows.Forms.Button();
            this.CalcWins = new System.Windows.Forms.Button();
            this.WinsLabel = new System.Windows.Forms.Label();
            this.NameLabel = new System.Windows.Forms.Label();
            this.SeriesWins = new System.Windows.Forms.Button();
            this.TeamBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(633, 364);
            this.exitButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(124, 60);
            this.exitButton.TabIndex = 14;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            // 
            // CalcWins
            // 
            this.CalcWins.Location = new System.Drawing.Point(370, 364);
            this.CalcWins.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.CalcWins.Name = "CalcWins";
            this.CalcWins.Size = new System.Drawing.Size(124, 60);
            this.CalcWins.TabIndex = 13;
            this.CalcWins.Text = "Calculate Wins";
            this.CalcWins.UseVisualStyleBackColor = true;
            this.CalcWins.Click += new System.EventHandler(this.Cal_Click);
            // 
            // WinsLabel
            // 
            this.WinsLabel.AutoSize = true;
            this.WinsLabel.Location = new System.Drawing.Point(549, 171);
            this.WinsLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.WinsLabel.Name = "WinsLabel";
            this.WinsLabel.Size = new System.Drawing.Size(129, 20);
            this.WinsLabel.TabIndex = 12;
            this.WinsLabel.Text = "Number of Wins";
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Location = new System.Drawing.Point(549, 88);
            this.NameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(98, 20);
            this.NameLabel.TabIndex = 11;
            this.NameLabel.Text = "Team Name";
            // 
            // SeriesWins
            // 
            this.SeriesWins.Location = new System.Drawing.Point(49, 364);
            this.SeriesWins.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.SeriesWins.Name = "SeriesWins";
            this.SeriesWins.Size = new System.Drawing.Size(157, 60);
            this.SeriesWins.TabIndex = 10;
            this.SeriesWins.Text = "Load Series Wins";
            this.SeriesWins.UseVisualStyleBackColor = true;
            this.SeriesWins.Click += new System.EventHandler(this.Wins_Click);
            // 
            // TeamBox
            // 
            this.TeamBox.FormattingEnabled = true;
            this.TeamBox.ItemHeight = 20;
            this.TeamBox.Location = new System.Drawing.Point(29, 14);
            this.TeamBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TeamBox.Name = "TeamBox";
            this.TeamBox.Size = new System.Drawing.Size(347, 284);
            this.TeamBox.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(889, 450);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.CalcWins);
            this.Controls.Add(this.WinsLabel);
            this.Controls.Add(this.NameLabel);
            this.Controls.Add(this.SeriesWins);
            this.Controls.Add(this.TeamBox);
            this.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Form1";
            this.Text = "WorldSeries";
            this.Click += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button CalcWins;
        private System.Windows.Forms.Label WinsLabel;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Button SeriesWins;
        private System.Windows.Forms.ListBox TeamBox;
    }
}

