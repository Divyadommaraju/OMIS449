﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WorldSeriesProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        List<string> WSWins = new List<string>();

        private List<string> ReadFile(List<string> s)
        {
            OpenFileDialog OpenFile = new OpenFileDialog
            {
                Filter = "TXT|*.txt"
            };

            if (OpenFile.ShowDialog() == DialogResult.OK)
            {
                s = System.IO.File.ReadAllLines(OpenFile.FileName).ToList();
            }

            else
                MessageBox.Show("Error Occured.");

            MessageBox.Show("Successfully loaded.");

            return s;
        }

        private void WSWinners(string T, List<string> W)
        {
            int Wins = 0;

            foreach (string Line in W)
            {
                if (Line == T)
                    Wins++;
            }

            if (TeamBox.SelectedIndex != -1)
            {
                NameLabel.Text = T.ToString();
            }

            WinsLabel.Text = Wins.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            List<string> Teams = new List<string>();

            Teams = ReadFile(Teams);

            foreach (string s in Teams)
            {
                TeamBox.Items.Add(s);
            }
        }

        private void Wins_Click(object sender, EventArgs e)
        {
            WSWins = ReadFile(WSWins);
        }

        private void Cal_Click(object sender, EventArgs e)
        {
            string Team = TeamBox.SelectedItem.ToString();

            WSWinners(Team, WSWins);
        }

     }
}
