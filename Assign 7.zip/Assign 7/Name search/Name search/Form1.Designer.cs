﻿namespace Name_search
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CheckButton = new System.Windows.Forms.Button();
            this.BOutput = new System.Windows.Forms.TextBox();
            this.GOutput = new System.Windows.Forms.TextBox();
            this.EnterLabel = new System.Windows.Forms.Label();
            this.BLabel = new System.Windows.Forms.Label();
            this.GLabel = new System.Windows.Forms.Label();
            this.BText = new System.Windows.Forms.TextBox();
            this.GText = new System.Windows.Forms.TextBox();
            this.BNames = new System.Windows.Forms.Button();
            this.GrlNames = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // CheckButton
            // 
            this.CheckButton.Location = new System.Drawing.Point(716, 238);
            this.CheckButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.CheckButton.Name = "CheckButton";
            this.CheckButton.Size = new System.Drawing.Size(124, 35);
            this.CheckButton.TabIndex = 19;
            this.CheckButton.Text = "Check";
            this.CheckButton.UseVisualStyleBackColor = true;
            this.CheckButton.Click += new System.EventHandler(this.CheckNames_Click);
            // 
            // BOutput
            // 
            this.BOutput.Enabled = false;
            this.BOutput.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BOutput.Location = new System.Drawing.Point(130, 388);
            this.BOutput.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BOutput.Name = "BOutput";
            this.BOutput.Size = new System.Drawing.Size(511, 28);
            this.BOutput.TabIndex = 18;
            // 
            // GOutput
            // 
            this.GOutput.Enabled = false;
            this.GOutput.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GOutput.Location = new System.Drawing.Point(130, 312);
            this.GOutput.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.GOutput.Name = "GOutput";
            this.GOutput.Size = new System.Drawing.Size(511, 28);
            this.GOutput.TabIndex = 17;
            // 
            // EnterLabel
            // 
            this.EnterLabel.AutoSize = true;
            this.EnterLabel.Location = new System.Drawing.Point(436, 47);
            this.EnterLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.EnterLabel.Name = "EnterLabel";
            this.EnterLabel.Size = new System.Drawing.Size(173, 20);
            this.EnterLabel.TabIndex = 16;
            this.EnterLabel.Text = "Enter a name for both.";
            // 
            // BLabel
            // 
            this.BLabel.AutoSize = true;
            this.BLabel.Location = new System.Drawing.Point(436, 177);
            this.BLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.BLabel.Name = "BLabel";
            this.BLabel.Size = new System.Drawing.Size(39, 20);
            this.BLabel.TabIndex = 15;
            this.BLabel.Text = "Boy";
            // 
            // GLabel
            // 
            this.GLabel.AutoSize = true;
            this.GLabel.Location = new System.Drawing.Point(436, 111);
            this.GLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.GLabel.Name = "GLabel";
            this.GLabel.Size = new System.Drawing.Size(36, 20);
            this.GLabel.TabIndex = 14;
            this.GLabel.Text = "Girl";
            // 
            // BText
            // 
            this.BText.Location = new System.Drawing.Point(546, 173);
            this.BText.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BText.Name = "BText";
            this.BText.Size = new System.Drawing.Size(164, 28);
            this.BText.TabIndex = 13;
            // 
            // GText
            // 
            this.GText.Location = new System.Drawing.Point(546, 111);
            this.GText.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.GText.Name = "GText";
            this.GText.Size = new System.Drawing.Size(164, 28);
            this.GText.TabIndex = 12;
            // 
            // BNames
            // 
            this.BNames.Location = new System.Drawing.Point(56, 144);
            this.BNames.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BNames.Name = "BNames";
            this.BNames.Size = new System.Drawing.Size(170, 55);
            this.BNames.TabIndex = 11;
            this.BNames.Text = "Boy Names";
            this.BNames.UseVisualStyleBackColor = true;
            this.BNames.Click += new System.EventHandler(this.BNames_Click);
            // 
            // GrlNames
            // 
            this.GrlNames.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GrlNames.Location = new System.Drawing.Point(56, 47);
            this.GrlNames.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.GrlNames.Name = "GrlNames";
            this.GrlNames.Size = new System.Drawing.Size(170, 55);
            this.GrlNames.TabIndex = 10;
            this.GrlNames.Text = " Girl Names";
            this.GrlNames.UseVisualStyleBackColor = true;
            this.GrlNames.Click += new System.EventHandler(this.GNames_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(889, 450);
            this.Controls.Add(this.CheckButton);
            this.Controls.Add(this.BOutput);
            this.Controls.Add(this.GOutput);
            this.Controls.Add(this.EnterLabel);
            this.Controls.Add(this.BLabel);
            this.Controls.Add(this.GLabel);
            this.Controls.Add(this.BText);
            this.Controls.Add(this.GText);
            this.Controls.Add(this.BNames);
            this.Controls.Add(this.GrlNames);
            this.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Form1";
            this.Text = "Name search";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CheckButton;
        private System.Windows.Forms.TextBox BOutput;
        private System.Windows.Forms.TextBox GOutput;
        private System.Windows.Forms.Label EnterLabel;
        private System.Windows.Forms.Label BLabel;
        private System.Windows.Forms.Label GLabel;
        private System.Windows.Forms.TextBox BText;
        private System.Windows.Forms.TextBox GText;
        private System.Windows.Forms.Button BNames;
        private System.Windows.Forms.Button GrlNames;
    }
}

