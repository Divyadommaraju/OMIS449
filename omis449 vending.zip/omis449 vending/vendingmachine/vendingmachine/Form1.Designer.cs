﻿namespace vendingmachine
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.TLabel = new System.Windows.Forms.Label();
            this.CreamLabel = new System.Windows.Forms.Label();
            this.CreamPrice = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.Gprice = new System.Windows.Forms.Label();
            this.LemonPrice = new System.Windows.Forms.Label();
            this.RootPrice = new System.Windows.Forms.Label();
            this.Cocacolap = new System.Windows.Forms.Label();
            this.GLabel = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.LemonLabel = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.RootLabel = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.TotalLabel = new System.Windows.Forms.Label();
            this.CLabel = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.exitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // TLabel
            // 
            this.TLabel.AutoSize = true;
            this.TLabel.Location = new System.Drawing.Point(83, 473);
            this.TLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.TLabel.Name = "TLabel";
            this.TLabel.Size = new System.Drawing.Size(98, 22);
            this.TLabel.TabIndex = 33;
            this.TLabel.Text = "Total Price";
            // 
            // CreamLabel
            // 
            this.CreamLabel.AutoSize = true;
            this.CreamLabel.Location = new System.Drawing.Point(472, 309);
            this.CreamLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.CreamLabel.Name = "CreamLabel";
            this.CreamLabel.Size = new System.Drawing.Size(99, 22);
            this.CreamLabel.TabIndex = 32;
            this.CreamLabel.Text = "Creamsoda";
            // 
            // CreamPrice
            // 
            this.CreamPrice.AutoSize = true;
            this.CreamPrice.Location = new System.Drawing.Point(472, 256);
            this.CreamPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.CreamPrice.Name = "CreamPrice";
            this.CreamPrice.Size = new System.Drawing.Size(150, 22);
            this.CreamPrice.TabIndex = 31;
            this.CreamPrice.Text = "Cream soda price";
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.BackgroundImage")));
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox5.Location = new System.Drawing.Point(287, 256);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(147, 75);
            this.pictureBox5.TabIndex = 30;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // Gprice
            // 
            this.Gprice.AutoSize = true;
            this.Gprice.Location = new System.Drawing.Point(660, 146);
            this.Gprice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Gprice.Name = "Gprice";
            this.Gprice.Size = new System.Drawing.Size(105, 22);
            this.Gprice.TabIndex = 29;
            this.Gprice.Text = "Grape price";
            // 
            // LemonPrice
            // 
            this.LemonPrice.AutoSize = true;
            this.LemonPrice.Location = new System.Drawing.Point(693, 14);
            this.LemonPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LemonPrice.Name = "LemonPrice";
            this.LemonPrice.Size = new System.Drawing.Size(145, 22);
            this.LemonPrice.TabIndex = 28;
            this.LemonPrice.Text = "LemonLimePrice";
            // 
            // RootPrice
            // 
            this.RootPrice.AutoSize = true;
            this.RootPrice.Location = new System.Drawing.Point(205, 136);
            this.RootPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.RootPrice.Name = "RootPrice";
            this.RootPrice.Size = new System.Drawing.Size(133, 22);
            this.RootPrice.TabIndex = 27;
            this.RootPrice.Text = "RootBeer Price";
            // 
            // Cocacolap
            // 
            this.Cocacolap.AutoSize = true;
            this.Cocacolap.Location = new System.Drawing.Point(205, 24);
            this.Cocacolap.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Cocacolap.Name = "Cocacolap";
            this.Cocacolap.Size = new System.Drawing.Size(83, 22);
            this.Cocacolap.TabIndex = 26;
            this.Cocacolap.Text = "CC Price";
            // 
            // GLabel
            // 
            this.GLabel.AutoSize = true;
            this.GLabel.Location = new System.Drawing.Point(660, 187);
            this.GLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.GLabel.Name = "GLabel";
            this.GLabel.Size = new System.Drawing.Size(59, 22);
            this.GLabel.TabIndex = 25;
            this.GLabel.Text = "Grape";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.BackgroundImage")));
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox4.Location = new System.Drawing.Point(477, 136);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(164, 73);
            this.pictureBox4.TabIndex = 24;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // LemonLabel
            // 
            this.LemonLabel.AutoSize = true;
            this.LemonLabel.Location = new System.Drawing.Point(693, 59);
            this.LemonLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LemonLabel.Name = "LemonLabel";
            this.LemonLabel.Size = new System.Drawing.Size(68, 22);
            this.LemonLabel.TabIndex = 23;
            this.LemonLabel.Text = "Lemon ";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(477, 11);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(164, 70);
            this.pictureBox3.TabIndex = 22;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // RootLabel
            // 
            this.RootLabel.AutoSize = true;
            this.RootLabel.Location = new System.Drawing.Point(205, 187);
            this.RootLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.RootLabel.Name = "RootLabel";
            this.RootLabel.Size = new System.Drawing.Size(86, 22);
            this.RootLabel.TabIndex = 21;
            this.RootLabel.Text = "RootBeer";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(39, 125);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(138, 84);
            this.pictureBox2.TabIndex = 20;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // TotalLabel
            // 
            this.TotalLabel.AutoSize = true;
            this.TotalLabel.Location = new System.Drawing.Point(220, 473);
            this.TotalLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.TotalLabel.Name = "TotalLabel";
            this.TotalLabel.Size = new System.Drawing.Size(56, 22);
            this.TotalLabel.TabIndex = 19;
            this.TotalLabel.Text = "Total ";
            // 
            // CLabel
            // 
            this.CLabel.AutoSize = true;
            this.CLabel.Location = new System.Drawing.Point(205, 59);
            this.CLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.CLabel.Name = "CLabel";
            this.CLabel.Size = new System.Drawing.Size(90, 22);
            this.CLabel.TabIndex = 18;
            this.CLabel.Text = "Coca cola";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.pictureBox1.Location = new System.Drawing.Point(39, 14);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(138, 79);
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(530, 473);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(111, 40);
            this.exitButton.TabIndex = 34;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(978, 579);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.TLabel);
            this.Controls.Add(this.CreamLabel);
            this.Controls.Add(this.CreamPrice);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.Gprice);
            this.Controls.Add(this.LemonPrice);
            this.Controls.Add(this.RootPrice);
            this.Controls.Add(this.Cocacolap);
            this.Controls.Add(this.GLabel);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.LemonLabel);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.RootLabel);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.TotalLabel);
            this.Controls.Add(this.CLabel);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form1";
            this.Text = "Vending";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label TLabel;
        private System.Windows.Forms.Label CreamLabel;
        private System.Windows.Forms.Label CreamPrice;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label Gprice;
        private System.Windows.Forms.Label LemonPrice;
        private System.Windows.Forms.Label RootPrice;
        private System.Windows.Forms.Label Cocacolap;
        private System.Windows.Forms.Label GLabel;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label LemonLabel;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label RootLabel;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label TotalLabel;
        private System.Windows.Forms.Label CLabel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button exitButton;
    }
}

