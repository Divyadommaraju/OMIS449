﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace vendingmachine
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
            struct Drinks
        {
            public string Name;
            public double Price;
            public int Amount;
            public double SubTotal;
        }
        private void CalcTotal()
        {
            double t;
            t = Soda[Cola].SubTotal + Soda[RootBeer].SubTotal + Soda[LemonLime].SubTotal +
                Soda[Grape].SubTotal + Soda[CreamSoda].SubTotal;
            TotalLabel.Text = t.ToString("c");
        }

        private double CalcSubTotal(double a, double p)
        {
            a = (25 - a) * p;

            return a;
        }

        private int BuySoda(int a)
        {
            if (a <= 0)
            {
                MessageBox.Show("Sorry,the soda is sold out!");
                return a;
            }

            else
            {
                a -= 1;
                return a;
            }
        }

        Drinks[] Soda = new Drinks[5];
        int Cola = 0;
        int RootBeer = 1;
        int LemonLime = 2;
        int Grape = 3;
        int CreamSoda = 4;
        double Total = 0.00;

        private void Form1_Load(object sender, EventArgs e)
        {
            Soda[Cola].Name = "Cola";
            Soda[Cola].Price = 1.00;
            Soda[Cola].Amount = 25;
            Soda[Cola].SubTotal = 0.00;
            Soda[RootBeer].Name = "Root Beer";
            Soda[RootBeer].Price = 1.00;
            Soda[RootBeer].Amount = 25;
            Soda[RootBeer].SubTotal = 0.00;
            Soda[LemonLime].Name = "Lemon Lime";
            Soda[LemonLime].Price = 1.25;
            Soda[LemonLime].Amount = 25;
            Soda[LemonLime].SubTotal = 0.00;
            Soda[Grape].Name = "Grape";
            Soda[Grape].Price = 1.69;
            Soda[Grape].Amount = 25;
            Soda[Grape].SubTotal = 0.00;
            Soda[CreamSoda].Name = "Cream Soda";
            Soda[CreamSoda].Price = 1.69;
            Soda[CreamSoda].Amount = 25;
            Soda[CreamSoda].SubTotal = 0.00;

            CLabel.Text = Soda[Cola].Amount.ToString();
            Cocacolap.Text = Soda[Cola].Price.ToString("c");

            RootLabel.Text = Soda[RootBeer].Amount.ToString();
            RootPrice.Text = Soda[RootBeer].Price.ToString("c");

            LemonLabel.Text = Soda[LemonLime].Amount.ToString();
            LemonPrice.Text = Soda[LemonLime].Price.ToString("c");

            GLabel.Text = Soda[Grape].Amount.ToString();
            Gprice.Text = Soda[Grape].Price.ToString("c");

            CreamLabel.Text = Soda[CreamSoda].Amount.ToString();
            CreamPrice.Text = Soda[CreamSoda].Price.ToString("c");

            TotalLabel.Text = Total.ToString("c");
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Soda[Cola].Amount = BuySoda(Soda[Cola].Amount);
            CLabel.Text = Soda[Cola].Amount.ToString();

            Soda[Cola].SubTotal = CalcSubTotal(Soda[Cola].Amount, Soda[Cola].Price);

            CalcTotal();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Soda[RootBeer].Amount = BuySoda(Soda[RootBeer].Amount);
            RootLabel.Text = Soda[RootBeer].Amount.ToString();

            Soda[RootBeer].SubTotal = CalcSubTotal(Soda[RootBeer].Amount, Soda[RootBeer].Price);

            CalcTotal();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Soda[LemonLime].Amount = BuySoda(Soda[LemonLime].Amount);
            LemonLabel.Text = Soda[LemonLime].Amount.ToString();

            Soda[LemonLime].SubTotal = CalcSubTotal(Soda[LemonLime].Amount, Soda[LemonLime].Price);

            CalcTotal();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Soda[Grape].Amount = BuySoda(Soda[Grape].Amount);
            GLabel.Text = Soda[Grape].Amount.ToString();

            Soda[Grape].SubTotal = CalcSubTotal(Soda[Grape].Amount, Soda[Grape].Price);

            CalcTotal();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Soda[CreamSoda].Amount = BuySoda(Soda[CreamSoda].Amount);
            CreamLabel.Text = Soda[CreamSoda].Amount.ToString();

            Soda[CreamSoda].SubTotal = CalcSubTotal(Soda[CreamSoda].Amount, Soda[CreamSoda].Price);

            CalcTotal();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}


